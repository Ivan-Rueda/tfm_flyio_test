package com.irueda.tfm_rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfmRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TfmRestApplication.class, args);
	}

}
