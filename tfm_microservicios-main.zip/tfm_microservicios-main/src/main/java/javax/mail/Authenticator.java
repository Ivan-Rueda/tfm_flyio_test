package javax.mail;

public class Authenticator {

}
