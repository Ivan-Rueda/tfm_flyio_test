package com.irueda.tfm_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfmRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
